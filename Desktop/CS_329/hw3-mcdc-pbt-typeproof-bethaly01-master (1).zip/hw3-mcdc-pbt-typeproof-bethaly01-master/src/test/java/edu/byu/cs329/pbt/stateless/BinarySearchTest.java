package edu.byu.cs329.pbt.stateless;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.stream.Stream;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

public class BinarySearchTest {
  public static Random rand = new Random();
  public static int MAX_SIZE = 30;
  public static int TEST_COUNT= 2;
  
  /**
   * cs329.requires: 
   *    array is non null.
   *    array is sorted by increasing value: 
   *       \forall i, 0 < i < array.length - 1 implies array[i] < array[i+1]
   * cs329.ensures:  
   *       true if an only if \exists i, 0 <= i < array.length /\ value == array[i]
   **/
  public static boolean search(int[] array, int value) {
    int left = 0;
    int right = array.length - 1;
    while (left <= right) {
      int index = (right + left) / 2;
      if (array[index] == value)
        return true;
      if (array[index] > value)
        right = index - 1;
      else
        left = index + 1;
    }
    return false;
  }
  
  boolean isSorted(int [] array){
    int previous = Integer.MIN_VALUE;
    for(int current : array){
      if(previous > current){
        return false;
      }
      previous = current;
    }
    return true;
  }

  /**
   * Generates a sort array
   */
  static int[] generateSortedArray(){
    int [] newArray = new int[rand.nextInt(MAX_SIZE)+1];
    int base = rand.nextInt();
    int max = Integer.max(base, base + rand.nextInt(Integer.MAX_VALUE));
    for(int i = 0 ; i < newArray.length; i ++){
      newArray[i] = base;
      if(max != base){
        base = base + rand.nextInt(max-base);
      }
    }
    return newArray;
  }

  /** Creates Random Input */
  static Stream<Arguments> generateRandomInputPositiveTest(){
    List<Arguments> inputs = new ArrayList<>();
    for (int i = 0 ; i < TEST_COUNT; i++){
      int [] arrayTest = generateSortedArray();
      int size = arrayTest.length;
      int index = rand.nextInt(size);
      int value = arrayTest[index];
      inputs.add(Arguments.of(arrayTest,value,true));
    }
    int [] arrayTest;
    for (int i = 0 ; i < TEST_COUNT; i++){
      arrayTest = generateSortedArray();
      int value;
      if(rand.nextInt()%2 == 0){
        value = arrayTest[0]-1;
      }else{
        value = arrayTest[arrayTest.length-1]+1;
      }
      inputs.add(Arguments.of(arrayTest,value,false));
    }
    arrayTest = new int[0];
    inputs.add(Arguments.of(arrayTest, 5,false));
    return inputs.stream();
  }

  /**Tests*/
  @ParameterizedTest(name="Should Return {2} given {1} in the array {0}")
  @DisplayName("Test Passes binary search ")
  @MethodSource("generateRandomInputPositiveTest")
  void should_Return_Expectations_When_Given_Arguments(int[] array, int value, boolean result){
    assertEquals(result, BinarySearchTest.search(array,value));
  }
}

