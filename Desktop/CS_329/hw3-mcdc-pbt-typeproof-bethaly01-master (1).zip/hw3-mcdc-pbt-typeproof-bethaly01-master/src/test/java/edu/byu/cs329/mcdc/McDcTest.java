package edu.byu.cs329.mcdc;

import static org.junit.Assert.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;



public class McDcTest {

  @Test
  @DisplayName("Coverage for the method f")
  public void testConditionCoverageConditionDecisionFor_f(){
    assertEquals(true,McDcTest.f(true,true,true,true));
    assertEquals(false,McDcTest.f(true,false,true,false));
    assertEquals(false,McDcTest.f(false,false,false,false));
    assertEquals(true,McDcTest.f(true,false,true,true));
  }

  @Test
  @DisplayName("Coverage for the method sort")
  public void conditionCoverageConditionDecisionFor_sort(){
    int [] arrayTest = new int[]{5,6,8,9,7};
    int [] arrayNew = new int[]{5,6,7,8,9};
    assertArrayEquals(arrayNew, McDcTest.sort(arrayTest, 0,4));
  }
  

  public static boolean f(boolean a, boolean b, boolean c, boolean d) {
    return (a && b) || (c && d);
  }
  
  public static int[] sort(int[] array, int from, int to) {
    if (from >= to) {
      return new int[] { array[from] };
    }

    int m = (from + to) / 2;
    int[] left = sort(array, from, m);
    int[] right = sort(array, m + 1, to);

    int[] result = new int[left.length + right.length];
    int li = 0;
    int ri = 0;
    for (int i = 0; i < result.length; i++) {
      if (li < left.length && (ri >= right.length || left[li] < right[ri])) {
        result[i] = left[li];
        li++;
      } else {
        result[i] = right[ri];
        ri++;
      }
    }

    return result;
  }

}