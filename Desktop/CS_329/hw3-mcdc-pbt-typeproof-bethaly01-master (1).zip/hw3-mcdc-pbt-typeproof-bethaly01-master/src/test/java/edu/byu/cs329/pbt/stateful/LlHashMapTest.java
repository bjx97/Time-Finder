package edu.byu.cs329.pbt.stateful;

import java.util.List;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.*;
import java.util.stream.*;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import edu.byu.cs329.hashtable.LlHashMap;

/**
 * Test suite for the hash table.
 */
public class LlHashMapTest {
  private static final int ADD_ELEMENT = 0;
  private static final int REMOVE_ELEMENT = 1;
  private static final int NUM_OPERATIONS = 2;
  private static final int NUM_TESTS = 5;
  private static final int MAX_VALUE = 50;
  private static final int MAX_OPS = 10;
  static Random r = new Random();
//create random prefix  add and removed
//test
//random suffix

  static Stream<Arguments> generateRandomProgram(){
    List<Arguments> args = new ArrayList<>();
    for (int i=0; i < NUM_TESTS; i++){
      int [] commands = new int[r.nextInt(MAX_OPS)+1];
      int [] commandsArg = new int[commands.length];
      int [] commandsKeys = new int[commands.length];
      for (int j = 0; j < commands.length; j++) {
        //1 ,0 (add, remove)
        commands[j] = r.nextInt(NUM_OPERATIONS);
        //a number between 0 - 50 -> value
        commandsArg[j] = r.nextInt(MAX_VALUE);
        //a number between 0 - 50 -> key
        commandsKeys[j] = r.nextInt(MAX_VALUE);
      }
      args.add(Arguments.of(commands,commandsArg,commandsKeys));
    }
    return args.stream();
  }

  static void runProgram (LlHashMap obj , int[] commands, int[] values,int [] keys ){
   /* ArrayList<Integer> indexKeys = new ArrayList<Integer>(); 
    ArrayList<Integer> indexValue = new ArrayList<Integer>(); */
    boolean emptyObj = emptyHashTable(commands);
    for(int i = 0; i < commands.length; i++){
      if(commands[i]== ADD_ELEMENT){
        obj.put(keys[i], values[i]);
      }else if (commands[i] == REMOVE_ELEMENT && !emptyObj ){
        obj.remove(keys[i]);
      }
    }
  }
/*
    int keyTest;
    int valueTest;
    boolean testA;
    if(!emptyObj){
       keyTest= keys[indexKeys.get(r.nextInt(indexKeys.size()-1))];
       valueTest= values[indexKeys.get(r.nextInt(indexValue.size()-1))];
    }else{
      keyTest= keys[(r.nextInt(commands.length-1))];
      valueTest= values[(r.nextInt(commands.length-1))];
    }
    testA= obj.contains(keyTest);

    obj.get(keyTest);
 
    /*
    testA= obj.contains(keyTest);
    keyTest = keys[r.nextInt(indexKeys.size())];
    obj.get(keyTest);
    keyTest = keys[r.nextInt(indexKeys.size())];*/
  

  static boolean emptyHashTable(int[] commands){
    for (int i : commands) {
      if(i == 0){
        return false;
      }
    } 
    return true;
  }

  private void testEquivalence(int[] ops, int[] values,int [] keys) {
    LlHashMap objUnderTest = new LlHashMap(ops.length);
    HashMap<Integer,Integer> goldStandard = new HashMap<>(ops.length);

    int stop = r.nextInt(ops.length); 
    runProgram(objUnderTest, ops, values,keys,0,stop);
    runProgram(goldStandard, ops, values,keys,0,stop);

    for (Map.Entry<Integer,Integer> entry : goldStandard.entrySet()) {
      assertTrue(objUnderTest.contains(entry.getKey()));
      assertEquals(entry.getValue(), objUnderTest.get(entry.getKey()));
    }
    assertTrue(objUnderTest.equals(goldStandard));
  }
  
 


  //to used this, create an Oracle
  static void runProgram (HashMap obj , int[] commands, int[] values,int [] keys, int start, int stop ){
    boolean emptyObj = emptyHashTable(commands);
    for(int i = start; i < stop; i++){
      if(commands[i] == ADD_ELEMENT){
        obj.put(keys[i], values[i]);
      }else if (commands[i] == REMOVE_ELEMENT  && !emptyObj){
        obj.remove(keys[i]);
      }
    }
  }

  static void runProgram (LlHashMap obj , int[] commands, int[] values,int [] keys, int start, int stop ){
    boolean emptyObj = emptyHashTable(commands);
    for(int i = start; i < stop; i++){
      if(commands[i] == ADD_ELEMENT){
        obj.put(keys[i], values[i]);
      }else if (commands[i] == REMOVE_ELEMENT  && !emptyObj){
        obj.remove(keys[i]);
      }
    }
  }

  @ParameterizedTest(name = "Should not throw exception when given {0} , keys : {2}, values {1} " )
  @DisplayName("Tests for Map with putElement and removeElement")
  @MethodSource("generateRandomProgram") 
  void testFroIntegerMapAddElementRevomeElement(int[] commands,int [] values, int [] keys){
    LlHashMap objA = new LlHashMap(commands.length);
    assertDoesNotThrow(()-> runProgram(objA, commands, values, keys));
  }

  @ParameterizedTest(name = "Test equivalencewhen given {0} , keys : {2}, values {1}")
  @DisplayName("Add/remove in random inputs should be equivalent")
  @MethodSource("generateRandomProgram")
  public void testEquivalenceOnRandomMaps(int[] ops, int[] values,int[] keys) {
    testEquivalence(ops, values,keys);
  }







    /*
    
      @ParameterizedTest(name = "Test equivalencewhen given {0} , keys : {2}, values {1}")
  @DisplayName("Add/remove in random inputs should be equivalent")
  @MethodSource("generateRandomProgram")
  public void testMethodsOnRandomMaps(int[] ops, int[] values,int[] keys) {
    testEquivalence(ops, values,keys);


    LlHashMap objB = new LlHashMap(MAX_BUCKET);

    assertDoesNotThrow(()-> runProgram(objA, commands, values, keys));
    int stop = r.nextInt(commands.length); 
    runProgram(objA, commands, values, keys, 0, stop);
    runProgram(objB, commands, values, keys, 0, stop);

    int key = r.nextInt(MAX_VALUE);
    int value = r.nextInt(MAX_VALUE);
    objA.remove(key);
    objA.put(key, value);
    objB.put(key, value);

    runProgram(objA, commands, values, keys,stop,commands.length);
    runProgram(objB, commands, values, keys,stop,commands.length);
    assertEquals(objA, objB);*/
}
